<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}
$dept_code = $_SESSION['dept_code'];
include ('conn.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <style>
        h1 {
            font-family: serif;
        }
        .edit-btn{
            background-color: #00ABF6;
            border-color: #00ABF6;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <?php 
        include "menubar.php"; 
    ?>
    <div class="content">
        <br>
        <h1>Employee List</h1>
        <br> <br>

        <table id="employeeTable" class="display responsive-table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Location ID</th>
                    <th>ID number</th>
                    <th>Verify Code</th>
                    <th>Card No.</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if($dept_code == '1'){
                    $sql = "SELECT * FROM tbl_employee";
                }else{
                $sql = "SELECT * FROM tbl_employee WHERE dept_code IN ($dept_code)";
                }
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {

                        $deptCode = $row['dept_code'];
                        $getdesc = "SELECT * FROM tbl_department WHERE dept_code = $deptCode";
                        $dept = $conn->query($getdesc);
                        $deptDesc = $dept->fetch_assoc();
                        if($dept ->num_rows > 0){
                        $empDept = $deptDesc['dept_desc'];
                        }else{$empDept = 0;}
                        echo "<tr>";
                        echo "<td>" . $row['employee_id'] . "</td>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $empDept . "</td>";
                        echo "<td>" . $row['location_id'] . "</td>";
                        echo "<td>" . $row['id_number'] . "</td>";
                        echo "<td>" . $row['verify_code'] . "</td>";
                        echo "<td>" . $row['card_no'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No employees found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    
        <script>
            $(document).ready(function() {
                $('#employeeTable').DataTable({
                    "lengthMenu": [5, 10, 20, 25, 50]
                });
            });
        </script>
    
    
    
    
    
    
    
    
    
    
    
    </div>
</body>
</html>
