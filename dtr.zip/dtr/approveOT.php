<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

include ('conn.php');

if(isset($_POST['otConfirm'])){
    $dtrID = $_POST['otConfirm'];
    $ot = 1;

    $approveotdtrSQL = "UPDATE tbl_dtr SET ot = ? WHERE id = ?";
    $approveotdtrStmt = $conn->prepare($approveotdtrSQL);
    $approveotdtrStmt->bind_param('ii', $ot, $dtrID);
    $approveotdtrStmt->execute();
    $approveotdtrStmt->close();

    $approveotinitialSQL = "UPDATE tbl_dtr SET ot = ? WHERE id = ?";
    $approveotinitialStmt = $conn->prepare($approveotinitialSQL);
    $approveotinitialStmt->bind_param('ii', $ot, $dtrID);
    $approveotinitialStmt->execute();
    $approveotinitialStmt->close();

    echo "<script>
    window.alert('OT approved!');
    window.location.href='dtr.php';
    </script>";
}
if(isset($_POST['revertConfirm'])){
    $dtrID = $_POST['revertConfirm'];
    $ot = 0;

    $approveotdtrSQL = "UPDATE tbl_dtr SET ot = ? WHERE id = ?";
    $approveotdtrStmt = $conn->prepare($approveotdtrSQL);
    $approveotdtrStmt->bind_param('ii', $ot, $dtrID);
    $approveotdtrStmt->execute();
    $approveotdtrStmt->close();

    $approveotinitialSQL = "UPDATE tbl_dtr SET ot = ? WHERE id = ?";
    $approveotinitialStmt = $conn->prepare($approveotinitialSQL);
    $approveotinitialStmt->bind_param('ii', $ot, $dtrID);
    $approveotinitialStmt->execute();
    $approveotinitialStmt->close();

    echo "<script>
    window.alert('Approved OT reverted!');
    window.location.href='dtr.php';
    </script>";
}

?>