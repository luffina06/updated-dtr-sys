<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$department_code = $_SESSION['dept_code'];
include ('conn.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="css.php">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    
    <style>
        .modal-csv{
            background-color: #00ABF6;
            font-weight: bold;
            border-radius: 5px;
        }
        h1 {
            font-family: serif;
        }
        .edit-btn{
            background-color: #00ABF6;
            border-color: #00ABF6;
            border-radius: 5px;
        }
        .approve-ot, .unapprove-ot{
            background-color: #00ABF6;
            border-color: #00ABF6;
            border-radius: 5px;
        }

        .cbutton{
            background-color: #00ABF6;
            border-color: #00ABF6;
            border-radius: 5px;
            font-weight: bold;
            margin-left: 35px;
            margin-right: 10px;
            margin-bottom: 10px;
        }

        .datefil input[type="date"] {
            width: 25%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .datefil input[type="submit"] {
            background-color: #00ABF6;;
            color: black;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
    </style>
</head>

<body>
    <?php 
        include "menubar.php"; 
///dates

function AMin($x){
    if($x == '00:00'){
        return true;
    }
}
function AMout($x){
    if($x == '00:00'){
        return true;
    }
}
function PMin($x){
    if($x == '00:00'){
        return true;
    }
}
function PMout($x){
    if($x == '00:00'){
        return true;
    }
}

$currentDate = date("Y-m-d");
$if_startDate = date("Y-m-01");
$if_endDate = date("Y-m-t");


    $start_date = date("Y-m-01");
    $end_date = date("Y-m-t");
    $syear = date("Y", strtotime($if_startDate));
    $smonth = date("F", strtotime($if_startDate));
    $sday = date("d", strtotime($if_startDate));

    $eday = date("d", strtotime($if_endDate));
    $eyear = date("Y", strtotime($if_endDate));
    $emonth = date("F", strtotime($if_endDate));

if (isset($_POST['submit_date'])) {
    if($_POST["start_date"] > $_POST["end_date"] || $_POST["start_date"] == null || $_POST["end_date"] == null){
        if ($currentDate >= $if_startDate && $currentDate <= $if_endDate) {
            $start_date = date("Y-m-1");
            $end_date = date("Y-m-15");
            $syear = date("Y", strtotime($start_date));
            $smonth = date("F", strtotime($start_date));
            $sday = date("d", strtotime($start_date));
    
            $eday = date("d", strtotime($end_date));
            $eyear = date("Y", strtotime($end_date));
            $emonth = date("F", strtotime($end_date));
        } else {
            $start_date = date("Y-m-16");
            $end_date = date("Y-m-t");
            $syear = date("Y", strtotime($start_date));
            $smonth = date("F", strtotime($start_date));
            $sday = date("d", strtotime($start_date));
    
            $eday = date("d", strtotime($end_date));
            $eyear = date("Y", strtotime($end_date));
            $emonth = date("F", strtotime($end_date));
        }
    }else{
        $start_date = date($_POST["start_date"]);
        $end_date = date($_POST["end_date"]);

        $syear = date("Y", strtotime($start_date));
        $smonth = date("F", strtotime($start_date));
        $sday = date("d", strtotime($start_date));

        $eday = date("d", strtotime($end_date));
        $eyear = date("Y", strtotime($end_date));
        $emonth = date("F", strtotime($end_date));
    }
}
$formatted_start_date = "$smonth $sday, $syear";
$formatted_end_date = "$emonth $eday, $eyear";

    ?>
    <div class="content">
        <br>
        <h1>Daily Time Record</h1>
        <br>
        <div class="datefil">
            <center>
            <h3>DTR from <?php echo "$formatted_start_date";?> to <?php echo "$formatted_end_date";?></h3>
                <form action="" method="post">
                    <label for="start_date">Start Date:</label>
                    <input type="date" id="start_date" name="start_date">
                    <label for="end_date">End Date:</label>
                    <input type="date" id="end_date" name="end_date">
                    <input type="submit" name="submit_date" value="Filter">
                </form>
            </center>
        </div>
        <button type="button" class="btn mt-3 mb-3 modal-csv" data-toggle="modal" data-target="#uploadModal" >Upload DTR CSV</button>
        <button type="button" class="btn mt-3 mb-3 modal-csv" data-toggle="modal" data-target="#checklistModal" >Print DTR</button> 

<!-- upload Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="uploadModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content"> 
            <form action="process_csv.php" method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="uploadModalLabel">Upload CSV</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="file" name="csvFile" accept=".csv" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="submit" class="btn btn-primary">Upload</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#uploadModal').on('shown.bs.modal', function() {
            $('#csvFile').focus(); 
        });
    });
</script>
<!-- upload Modal -->
        <table id="dtrTable" class="display responsive-table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Morning <br>Clock-In</th>
                    <th>Morning <br>Clock-Out</th>
                    <th>Afternoon <br>Clock-In</th>
                    <th>Afternoon <br>Clock-out</th>
                    <th>Total Hours</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if($department_code == '1'){
                    $sql = "SELECT * FROM tbl_dtr WHERE date BETWEEN '$start_date' AND '$end_date'";
                }else{
                $sql = "SELECT * FROM tbl_dtr WHERE dept_code IN ($department_code) AND date BETWEEN '$start_date' AND '$end_date'";
                }
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $ot = $row['ot'];
                        $deptCode = $row['dept_code'];
                        $getdesc = "SELECT * FROM tbl_department WHERE dept_code = $deptCode";
                        $dept = $conn->query($getdesc);
                        $deptDesc = $dept->fetch_assoc();
                        if($dept ->num_rows > 0){
                        $empDept = $deptDesc['dept_desc'];
                        }else{$empDept = 0;}
                        if($ot == 1){
                            $total = $row['totalhours'];
                            
                            $attendedHours = floor($total);
                            $attendedMinutes = round(($total - $attendedHours) * 60);

                            $attended = "<b>Hrs: " . $attendedHours . "<br>Mins: " . $attendedMinutes;
                            if ($total < 0) {
                                $attended = "<b>Hrs: " . 0 . "<br>Mins: " . 0;
                            }
                            $date = new DateTime($row['date']);
                            $formatted_date = $date->format('m/d/Y');

                            $amclockin = $row['am_clockin'];
                            $amclockout = $row['am_clockout'];
                            $pmclockin = $row['pm_clockin'];
                            $pmclockout = $row['pm_clockout'];

                            $amtimein = new DateTime($amclockin);
                            $amtimeout = new DateTime($amclockout);
                            $pmtimein = new DateTime($pmclockin);
                            $pmtimeout = new DateTime($pmclockout);

                            $formatted_timeamin = $amtimein->format('H:i');
                            $formatted_timeamout = $amtimeout->format('H:i');
                            $formatted_timepmin = $pmtimein->format('H:i');
                            $formatted_timepmout = $pmtimeout->format('H:i');

                            $resamin = AMin($formatted_timeamin);
                            $resamout = AMout($formatted_timeamout);
                            $respmin = PMin($formatted_timepmin);
                            $respmout = PMout($formatted_timepmout);

                            echo "<tr>";
                            echo "<td>" . $row['employee_id'] . "</td>";
                            echo "<td>" . $row['name'] . "</td>";
                            echo "<td>" . $empDept . "</td>";
                            if($resamin){
                                echo "<td style = 'background-color: yellow'>" . $formatted_timeamin . "</td>";
                            }else{
                                echo "<td>" . $formatted_timeamin . "</td>";
                            }
                            if($resamout){
                                echo "<td style = 'background-color: yellow'>" . $formatted_timeamout . "</td>";
                            }else{
                                echo "<td>" . $formatted_timeamout . "</td>";
                            }
                            if($respmin){
                                echo "<td style = 'background-color: yellow'>" . $formatted_timepmin . "</td>";
                            }else{
                                echo "<td>" . $formatted_timepmin . "</td>";
                            }
                            if($respmout){
                                echo "<td style = 'background-color: yellow'>" . $formatted_timepmout . "</td>";
                            }else{
                                echo "<td>" . $formatted_timepmout . "</td>";
                            }
                            echo "<td>" . $attended . "</td>";
                            echo "<td>" . $formatted_date . "</td>";
                            ?>
                            <td>
                                <button type="button" class="edit-btn" id ="edit-btn" data-toggle="modal" data-target="#editmodal" 
                                data-dtrid="<?php echo $row['id']; ?>"
                                data-empname="<?php echo $row['name']; ?>"
                                data-empid="<?php echo $row['employee_id']; ?>"
                                data-amin="<?php echo $formatted_timeamin; ?>"
                                data-amout="<?php echo $formatted_timeamout; ?>"
                                data-pmin="<?php echo $formatted_timepmin; ?>"
                                data-pmout="<?php echo $formatted_timepmout; ?>"
                                data-dtrdate="<?php echo $row['date']; ?>"
                                >Edit</button>

                                <button type="button" class="unapprove-ot" id="unapprove-ot" data-id='<?php echo $row["id"] ?>' data-toggle="modal" data-target="#unapproveOTmodal">
                                    Revert Approved OT
                                </button>
                            </td>
    <?php                   echo "</tr>";
                        }else if($ot == 0){
                            $total = $row['totalhours'];
                            $remaining = 0;
                            if($total >= 8){
                                $remaining = $total - 8;
                                $total = 8;
                            }

                            $attendedHours = floor($total);
                            $attendedMinutes = round(($total - $attendedHours) * 60);

                            $otHours = floor($remaining);
                            $otMinutes = round(($remaining - $otHours) * 60);

                            

                            $attended = "<b> Hrs: " . $attendedHours . "<br>Mins: " . $attendedMinutes . "<br>---<br>OT hrs: " . $otHours . "<br>OT mins: ". $otMinutes;
                            if ($total < 0) {
                                $attended = "<b>Hrs: " . 0 . "<br>Mins: " . 0;
                            }
                            $date = new DateTime($row['date']);
                            $formatted_date = $date->format('m/d/Y');

                            $amclockin = $row['am_clockin'];
                            $amclockout = $row['am_clockout'];
                            $pmclockin = $row['pm_clockin'];
                            $pmclockout = $row['pm_clockout'];

                            $amtimein = new DateTime($amclockin);
                            $amtimeout = new DateTime($amclockout);
                            $pmtimein = new DateTime($pmclockin);
                            $pmtimeout = new DateTime($pmclockout);

                            $formatted_timeamin = $amtimein->format('H:i');
                            $formatted_timeamout = $amtimeout->format('H:i');
                            $formatted_timepmin = $pmtimein->format('H:i');
                            $formatted_timepmout = $pmtimeout->format('H:i');

                            $resamin = AMin($formatted_timeamin);
                            $resamout = AMout($formatted_timeamout);
                            $respmin = PMin($formatted_timepmin);
                            $respmout = PMout($formatted_timepmout);

                            
                            echo "<tr>";
                            echo "<td>" . $row['employee_id'] . "</td>";
                            echo "<td>" . $row['name'] . "</td>";
                            echo "<td>" . $empDept . "</td>";
                            if($resamin){
                                echo "<td style = 'background-color: yellow'>" . $formatted_timeamin . "</td>";
                            }else{
                                echo "<td>" . $formatted_timeamin . "</td>";
                            }
                            if($resamout){
                                echo "<td style = 'background-color: yellow'>" . $formatted_timeamout . "</td>";
                            }else{
                                echo "<td>" . $formatted_timeamout . "</td>";
                            }
                            if($respmin){
                                echo "<td style = 'background-color: yellow'>" . $formatted_timepmin . "</td>";
                            }else{
                                echo "<td>" . $formatted_timepmin . "</td>";
                            }
                            if($respmout){
                                echo "<td style = 'background-color: yellow'>" . $formatted_timepmout . "</td>";
                            }else{
                                echo "<td>" . $formatted_timepmout . "</td>";
                            }
                            echo "<td>" . $attended . "</td>";
                            echo "<td>" . $formatted_date . "</td>";
                            ?>
                            <td>
                                <button type="button" class="edit-btn" id ="edit-btn" data-toggle="modal" data-target="#editmodal" 
                                data-dtrid="<?php echo $row['id']; ?>"
                                data-empname="<?php echo $row['name']; ?>"
                                data-empid="<?php echo $row['employee_id']; ?>"
                                data-amin="<?php echo $formatted_timeamin; ?>"
                                data-amout="<?php echo $formatted_timeamout; ?>"
                                data-pmin="<?php echo $formatted_timepmin; ?>"
                                data-pmout="<?php echo $formatted_timepmout; ?>"
                                data-dtrdate="<?php echo $row['date']; ?>"
                                >Edit</button>

                                <button type="button" class="approve-ot" id="approve-ot" data-id='<?php echo $row["id"] ?>' data-toggle="modal" data-target="#approveOTmodal">
                                    Approve OT
                                </button>
                            </td>
    <?php                   echo "</tr>";
                        }
                    }
                } else {
                    echo "<tr><td colspan='10'>No DTR found</td></tr>";
                }
                ?>
            </tbody>
        </table>
<!-- edit btn modal -->
<div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Edit DTR Details </h5>
                    <button onclick="window.location.href='dtr.php'" type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="edit_dtr.php" method="POST">

                    <div class="modal-body">

                        <div class="form-group">

                        <label for="empName" class="form-label">Employee Name</label>
                        <input type="text" class="form-control" id="empName" name="empName" value="" readonly>
                        </div>
                        <div class="form-group">
                        <label for="selectedName_ID" class="form-label">Employee ID</label>
                        <input type="number" class="form-control" id="selectedName_ID" name="selectedName_ID" value="" readonly>
                            
                        </div>
                        <div class="form-group">
                        <label for="AMin" class="form-label">Morning Clock-In</label>
                        <input type="time" class="form-control" id="AMin" name="AMin" value="">
                        </div>
                    
                        <div class="form-group">
                           <label for="AMout" class="form-label">Morning Clock-Out</label>
                        <input type="time" class="form-control" id="AMout" name="AMout" value="">
                        </div>
                        <div class="form-group">
                        <label for="PMin" class="form-label">Afternoon Clock-In</label>
                        <input type="time" class="form-control" id="PMin" name="PMin" value="">
                        </div>
                      
                        <div class="form-group">
                           <label for="AMout" class="form-label">Afternoon Clock-Out</label>
                        <input type="time" class="form-control" id="PMout" name="PMout" value="">
                        </div>

                        <div class="form-group">
                            <label for="lunch" class="form-label">Set Break Time <b style = "color: red;">**</b></label>
                            <select class="form-control" id="lunch" name="lunch" required>
                                <option value="0">no lunch</option>
                                <option value="20">20 minutes</option>
                                <option value="30">30 minutes</option>
                                <option value="45">45 minutes</option>
                                <option value="60">1 hour</option>
                                <option value="90">1 hour and 30 minutes</option>
                                <option value="120">2 hours</option>
                            </select>
                        </div> 
            
                        <div class="form-group">
                        <label for="selected_date" class="form-label">Date</label>
                        <input type="date" class="form-control" id="selected_date" name="selected_date" value="" readonly>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button onclick="window.location.href='dtr.php'" type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button id = 'updConfirm' type="submit" name="updatedata" class="btn btn-primary" value = ''>Update Data</button>
                        <script>
                            $(document).on("click", ".edit-btn", function () {

                                var dtr_id = $(this).data('dtrid');
                                var empnamee = $(this).data('empname');
                                var emp_idd = $(this).data('empid');
                                var amiin = $(this).data('amin');
                                var amoout = $(this).data('amout'); 
                                var pmiin = $(this).data('pmin');
                                var pmoout = $(this).data('pmout');
                                var dtrdatee = $(this).data('dtrdate');

                                if(amiin == '00:00'){
                                    amiin = null;
                                }
                                if(amoout == '00:00'){
                                    amoout = null;
                                }
                                if(pmiin == '00:00'){
                                    pmiin = null;
                                }
                                if(pmoout == '00:00'){
                                    pmoout = null;
                                }
                                $('#updConfirm').val(dtr_id); 
                                $('#empName').val(empnamee); 
                                $('#selectedName_ID').val(emp_idd); 
                                $('#AMin').val(amiin); 
                                $('#AMout').val(amoout);
                                $('#PMin').val(pmiin);
                                $('#PMout').val(pmoout);
                                $('#selected_date').val(dtrdatee);

                                $('#editmodal').modal('show');
                            });
                        </script>
                    </div>
                </form>

            </div>
        </div>
    </div>
<!--ot modal -->
<!-- approve -->
<div class="modal fade" id="approveOTmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Approve Over Time</h5>
                    <button onclick="window.location.href='dtr.php'" type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="approveOT.php" method="POST">

                    <div class="modal-body">
                        <h6> Approve this Overtime?</h6>
                        
                    </div>
                    <div class="modal-footer">
                        <button onclick="window.location.href='dtr.php'" type="button" class="btn btn-secondary" data-bs-dismiss="modal"> No </button>
                       
                        <button id = 'otConfirm' type="submit" name="otConfirm" class="btn btn-success" value = ''> Yes </button>
                        <script>
                            $(document).on("click", ".approve-ot", function () {
                                var approveOT = $(this).data("id");
                                $("#otConfirm").val(approveOT);
                            });
                        </script>
                    </div>
                </form>

            </div>
        </div>
    </div>
<!-- revert -->
<div class="modal fade" id="unapproveOTmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Revert Approval of Over Time</h5>
                    <button onclick="window.location.href='dtr.php'" type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="approveOT.php" method="POST">

                    <div class="modal-body">
                        <h6> Revert approval of Overtime?</h6>
                    </div>
                    <div class="modal-footer">
                        <button onclick="window.location.href='dtr.php'" type="button" class="btn btn-secondary" data-bs-dismiss="modal"> No </button>
                       
                        <button id = 'revertConfirm' type="submit" name="revertConfirm" class="btn btn-success" value = ''> Yes </button>
                        <script>
                            $(document).on("click", ".unapprove-ot", function () {
                                var approveOT = $(this).data("id");
                                $("#revertConfirm").val(approveOT);
                            });
                        </script>
                    </div>
                </form>

            </div>
        </div>
    </div>
<!-- ot modal --end-->
<!-- print dtr modal -->
<div class="modal fade" id="checklistModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Select Employees to Print </h5>
                    <button onclick="window.location.href='dtr.php'" type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="" method="POST">
                        <div class= "ccbutton">
                            <button onclick="checkAll(this)" class="btn cbutton">Check All</button>
                            <button onclick="uncheckAll(this)"class="btn cbutton">Uncheck All</button>
                            <button type="submit" name = "dtrnamesSubmit" id = "employeeSelection" class="btn cbutton" >Submit</button>
                        </div>
                        <div class="form-group">
                            <label for="month" class="form-label">Select Month<b style = "color: red;">**</b></label>
                            <select class="form-control" id="month" name="month">
                                <option></option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                            <label for="year" class="form-label">Enter Year:</label>
                            <input class="form-control" type="number" id="year" name="year" min="2020" max="9999">
                        </div> 
                        <table class="table table-striped" id="tableIDIDD">
                            <thead>
                                <tr>
                                    <th>Select</th>
                                    <th>Name</th>
                                    <th>Dept</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                if($department_code == '1'){
                                    $getchecklist = "SELECT *  FROM tbl_employee";
                                }else{
                                    $getchecklist = "SELECT *  FROM tbl_employee WHERE dept_code IN ($department_code)";
                                }
                                $resultChecklist = mysqli_query($conn, $getchecklist);
                                if ($resultChecklist) {
                                    while ($list = mysqli_fetch_assoc($resultChecklist)) {
                                        $employee = $list['name'];
                                        $idemployee = $list['employee_id'];
                                        $departmentCode = $list['dept_code'];

                                        $depdep = "SELECT dept_desc FROM tbl_department WHERE dept_code = ?";
                                        $deepStmt = $conn->prepare($depdep);
                                        $deepStmt->bind_param('i', $departmentCode);
                                        $deepStmt->execute();
                                        $result = $deepStmt->get_result();
                                        $deptCode = $result->fetch_assoc();
                    
                                        if ($deptCode) {
                                            $depart = $deptCode['dept_desc'];
                                        }
                                        $deepStmt->close();

                            ?>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <center>
                                                <input type="checkbox" class="form-check-input" name="empNamess[]" value="<?php echo $idemployee; ?>" >
                                            </center>
                                        </div>
                                    </td>
                                    <td><?php echo $employee ?></td>
                                    <td><?php echo $depart ?></td>
                                </tr>
                            <?php
                                    }
                                }
                            ?>
                            </tbody>
                        </table>

                    </form>
                </div>                
            </div>
        </div>
    </div>

    <script>
        function checkAll(button) {
            event.preventDefault();
            var checkboxes = document.querySelectorAll('.form-check-input');
            for (var i = 0; i < checkboxes.length; i++) {
                checkboxes[i].checked = true;
            }
        }
        function uncheckAll(button) {
            event.preventDefault();
            var checkboxes = document.querySelectorAll('.form-check-input');
            for (var i = 0; i < checkboxes.length; i++) {
                checkboxes[i].checked = false;
            }
        }
    </script>
 <!-- print dtr modal end -->
<!-- continue modal send -->
 <?php
 if(isset($_POST['dtrnamesSubmit'])){
    $_SESSION['month'] = $_POST['month'];
    $_SESSION['year'] = $_POST['year'];
    if (isset($_POST['empNamess']) && is_array($_POST['empNamess'])) {
        $_SESSION['selectedIDs'] = $_POST['empNamess'];
    } else {
        $_SESSION['selectedIDs'] = 0;
    }

    echo "<script>window.location = 'print.php';</script>";
 }
 ?>
 <!-- continue modal send end -->
        <script>
            $(document).ready(function() {
                $('#dtrTable').DataTable({
                    "lengthMenu": [5, 10, 20, 25, 50],
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('#tableIDIDD').DataTable({
                    "pageLength": 10,
                    lengthChange: false
                });
            });
        </script>

    
    
    
    
        
    
    
    
    
    </div>
</body>
</html>