<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}
include 'conn.php';

if (isset($_POST['submit'])) {
    // Check if a file has been uploaded
    if (isset($_FILES['csvFile']) && $_FILES['csvFile']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['csvFile']['tmp_name'];
        $fileName = $_FILES['csvFile']['name'];
        $fileSize = $_FILES['csvFile']['size'];
        $fileType = $_FILES['csvFile']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        $allowedfileExtensions = array('csv');
        if (in_array($fileExtension, $allowedfileExtensions)) {
            if (($handle = fopen($fileTmpPath, 'r')) !== FALSE) {
                fgetcsv($handle);
                while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                    $department = $data[0];
                    $name = $data[1];
                    $employeeID = $data[2];
                    $locationId = $data[5];
                    $idNumber = $data[6];
                    $verifyCode = $data[7];
                    $cardNo = $data[8];

//check existing dept and insert
                    $deptSql = "SELECT * FROM tbl_department WHERE dept_desc = ?";
                    $deptStmt = $conn->prepare($deptSql);
                    $deptStmt->bind_param('s', $department);
                    $deptStmt->execute();
                    $deptStmt->store_result();

                    if ($deptStmt->num_rows == 0) {
                        $insertDeptSql = "INSERT INTO tbl_department (dept_desc) VALUES (?)";
                        $insertDeptStmt = $conn->prepare($insertDeptSql);
                        $insertDeptStmt->bind_param('s', $department);
                        $insertDeptStmt->execute();
                        $insertDeptStmt->close();
                    }
                    $deptStmt->close();
//get dept code
                    $depdep = "SELECT dept_code FROM tbl_department WHERE dept_desc = ?";
                    $deepStmt = $conn->prepare($depdep);
                    $deepStmt->bind_param('s', $department);
                    $deepStmt->execute();
                    $result = $deepStmt->get_result();
                    $deptCode = $result->fetch_assoc();

                    if ($deptCode) {
                        $deptcode = $deptCode['dept_code'];
                    }
                    $deepStmt->close();
//check existing employee and (insert or update)
                    $employeeSQL = "SELECT * FROM tbl_employee WHERE employee_id = ?";
                    $employeeStmt = $conn->prepare($employeeSQL);
                    $employeeStmt->bind_param('s', $employeeID);
                    $employeeStmt->execute();
                    $employeeStmt->store_result();

                    if ($employeeStmt->num_rows == 0) {
                        $insertEmpSql = "INSERT INTO tbl_employee (employee_id, name, dept_code, location_id, id_number, verify_code, card_no) VALUES (?, ?, ?, ?, ?, ?, ?)";
                        $insertEmpStmt = $conn->prepare($insertEmpSql);
                        $insertEmpStmt->bind_param('isiiisi', $employeeID, $name, $deptcode, $locationId, $idNumber, $verifyCode, $cardNo);
                        $insertEmpStmt->execute();
                        $insertEmpStmt->close();
                    }else{
                        $updateEmpSql = "UPDATE tbl_employee SET name = ?, dept_code = ?, location_id = ?, id_number = ?, verify_code = ?, card_no = ? WHERE employee_id = ?";
                        $updateEmpStmt = $conn->prepare($updateEmpSql);
                        $updateEmpStmt->bind_param('siiisii', $name, $deptcode, $locationId, $idNumber, $verifyCode, $cardNo, $employeeID);
                        $updateEmpStmt->execute();
                        $updateEmpStmt->close();
                    }
                    $employeeStmt->close();
//problem// insert clock in and out to db as initial
                    $datetime = $data[3];
                    $inout = $data[4];

                    $date = date("Y-m-d", strtotime($datetime)); 
                    $time = date("H:i", strtotime($datetime));

                    if(strtolower($inout) == "c/in"){
                        if($time < '12:00'){
                            $dtramSQL = "SELECT * FROM tbl_initialdtr WHERE employee_id = ? AND date = ?";
                            $dtramStmt = $conn->prepare($dtramSQL);
                            $dtramStmt->bind_param('ss', $employeeID, $date);
                            $dtramStmt->execute();
                            $dtramStmt->store_result();

                            if($dtramStmt->num_rows == 0){
                                $insertDTRSql = "INSERT INTO tbl_initialdtr (employee_id, am_clockin, date) VALUES (?, ?, ?)";
                                $insertDTRStmt = $conn->prepare($insertDTRSql);
                                $insertDTRStmt->bind_param('iss', $employeeID, $time, $date);
                                $insertDTRStmt->execute();
                                $insertDTRStmt->close();
                            }else{
                                $compareSQL = "SELECT * FROM tbl_initialdtr WHERE employee_id = ? AND date = ?";
                                $compareStmt = $conn->prepare($compareSQL);
                                $compareStmt->bind_param('ss', $employeeID, $date);
                                $compareStmt->execute();
                                $compareResult = $compareStmt->get_result();
                                $compare = $compareResult->fetch_assoc();
                    
                                $amcompare = $compare['am_clockin'];
                                $compareStmt->close();
                                if($time > $amcompare && $time != $amcompare){
                                    $updateDtrSql = "UPDATE tbl_initialdtr SET pm_clockin = ? WHERE employee_id = ? and date = ?";
                                    $updateDtrStmt = $conn->prepare($updateDtrSql);
                                    $updateDtrStmt->bind_param('sis', $time, $employeeID, $date);
                                    $updateDtrStmt->execute();
                                    $updateDtrStmt->close();
                                }
                            }
                        }else if($time >= '12:00'){
                            $dtrSQL = "SELECT * FROM tbl_initialdtr WHERE employee_id = ? AND date = ?";
                            $dtrStmt = $conn->prepare($dtrSQL);
                            $dtrStmt->bind_param('ss', $employeeID, $date);
                            $dtrStmt->execute();
                            $dtrStmt->store_result();
                            if($dtrStmt->num_rows == 0){
                                $insertSql = "INSERT INTO tbl_initialdtr (employee_id, pm_clockin, date) VALUES (?, ?, ?)";
                                $insertStmt = $conn->prepare($insertSql);
                                $insertStmt->bind_param('iss', $employeeID, $time, $date);
                                $insertStmt->execute();
                                $insertStmt->close();
                            }else{
                                $updateEmpSql = "UPDATE tbl_initialdtr SET pm_clockin = ? WHERE employee_id = ? and date = ?";
                                $updateEmpStmt = $conn->prepare($updateEmpSql);
                                $updateEmpStmt->bind_param('sis', $time, $employeeID, $date);
                                $updateEmpStmt->execute();
                                $updateEmpStmt->close();
                            }
                        }
                    }else if(strtolower($inout) == "c/out"){
                        if($time < '12:00'){
                            $dtrrSQL = "SELECT * FROM tbl_initialdtr WHERE employee_id = ? AND date = ?";
                            $initialStmt = $conn->prepare($dtrrSQL);
                            $initialStmt->bind_param('ss', $employeeID, $date);
                            $initialStmt->execute();
                            $initialStmt->store_result();
                            if($initialStmt->num_rows == 0){
                                $insertDTRSql = "INSERT INTO tbl_initialdtr (employee_id, am_clockout, date) VALUES (?, ?, ?)";
                                $insertDTRStmt = $conn->prepare($insertDTRSql);
                                $insertDTRStmt->bind_param('iss', $employeeID, $time, $date);
                                $insertDTRStmt->execute();
                                $insertDTRStmt->close();
                            }else{
                                $compareSQL = "SELECT * FROM tbl_initialdtr WHERE employee_id = ? AND date = ?";
                                $compareStmt = $conn->prepare($compareSQL);
                                $compareStmt->bind_param('ss', $employeeID, $date);
                                $compareStmt->execute();
                                $compareResult = $compareStmt->get_result();
                                $compare = $compareResult->fetch_assoc();
                    
                                $amclockoutcompare = $compare['am_clockout'];
                                $compareStmt->close();

                                if($amclockoutcompare == '00:00:00'){ 
                                    $updateDtrSql = "UPDATE tbl_initialdtr SET am_clockout = ? WHERE employee_id = ? and date = ?";
                                    $updateDtrStmt = $conn->prepare($updateDtrSql);
                                    $updateDtrStmt->bind_param('sis', $time, $employeeID, $date);
                                    $updateDtrStmt->execute();
                                    $updateDtrStmt->close();
                                }else if($amclockoutcompare != '00:00:00' && $time > $amclockoutcompare){
                                    $updateDtrSql = "UPDATE tbl_initialdtr SET pm_clockout = ? WHERE employee_id = ? and date = ?";
                                    $updateDtrStmt = $conn->prepare($updateDtrSql);
                                    $updateDtrStmt->bind_param('sis', $time, $employeeID, $date);
                                    $updateDtrStmt->execute();
                                    $updateDtrStmt->close();
                                }
                            }
                        }else if($time >= '12:00'){
                            $dtrrrSQL = "SELECT * FROM tbl_initialdtr WHERE employee_id = ? AND date = ?";
                            $iinitialStmt = $conn->prepare($dtrrrSQL);
                            $iinitialStmt->bind_param('ss', $employeeID, $date);
                            $iinitialStmt->execute();
                            $iinitialStmt->store_result();

                            if($iinitialStmt->num_rows == 0){
                                $insertDTRSql = "INSERT INTO tbl_initialdtr (employee_id, pm_clockout, date) VALUES (?, ?, ?)";
                                $insertDTRStmt = $conn->prepare($insertDTRSql);
                                $insertDTRStmt->bind_param('iss', $employeeID, $time, $date);
                                $insertDTRStmt->execute();
                                $insertDTRStmt->close();
                            }else{

                                $compareSQL = "SELECT * FROM tbl_initialdtr WHERE employee_id = ? AND date = ?";
                                $compareStmt = $conn->prepare($compareSQL);
                                $compareStmt->bind_param('is', $employeeID, $date);
                                $compareStmt->execute();
                                $compareResult = $compareStmt->get_result();
                                $compare = $compareResult->fetch_assoc();
                                
                                $amclockincompare = $compare['am_clockin'];
                                $amclockoutcompare = $compare['am_clockout'];
                                $pmclockincompare = $compare['pm_clockin'];
                                $pmclockoutcompare = $compare['pm_clockout'];
                                $compareStmt->close();
                                
                                if($amclockincompare != '00:00:00' && $amclockoutcompare == '00:00:00' && $pmclockincompare == '00:00:00'){
                                    $updateDtrSql = "UPDATE tbl_initialdtr SET pm_clockout = ? WHERE employee_id = ? AND date = ?";
                                    $updateDtrStmt = $conn->prepare($updateDtrSql);
                                    $updateDtrStmt->bind_param('sis', $time, $employeeID, $date);
                                    $updateDtrStmt->execute();
                                    $updateDtrStmt->close(); 
                                }else if($amclockincompare != '00:00:00' && $amclockoutcompare == '00:00:00' && $pmclockincompare != '00:00:00' && $pmclockoutcompare != '00:00:00'){
                                    $updateDtrSql = "UPDATE tbl_initialdtr SET am_clockout = ? WHERE employee_id = ? AND date = ?";
                                    $updateDtrStmt = $conn->prepare($updateDtrSql);
                                    $updateDtrStmt->bind_param('sis', $pmclockoutcompare, $employeeID, $date);
                                    $updateDtrStmt->execute();
                                    $updateDtrStmt->close(); 
                                    ///
                                    $updateDtrSql = "UPDATE tbl_initialdtr SET pm_clockout = ? WHERE employee_id = ? AND date = ?";
                                    $updateDtrStmt = $conn->prepare($updateDtrSql);
                                    $updateDtrStmt->bind_param('sis', $time, $employeeID, $date);
                                    $updateDtrStmt->execute();
                                    $updateDtrStmt->close(); 
                                }else if($amclockincompare == '00:00:00' && $amclockoutcompare == '00:00:00' && $pmclockincompare != '00:00:00'){
                                    $updateDtrSql = "UPDATE tbl_initialdtr SET pm_clockout = ? WHERE employee_id = ? AND date = ?";
                                    $updateDtrStmt = $conn->prepare($updateDtrSql);
                                    $updateDtrStmt->bind_param('sis', $time, $employeeID, $date);
                                    $updateDtrStmt->execute();
                                    $updateDtrStmt->close();
                                }else if($amclockincompare != '00:00:00' && $amclockoutcompare != '00:00:00' && $pmclockincompare != '00:00:00'){
                                    $updateDtrSql = "UPDATE tbl_initialdtr SET pm_clockout = ? WHERE employee_id = ? AND date = ?";
                                    $updateDtrStmt = $conn->prepare($updateDtrSql);
                                    $updateDtrStmt->bind_param('sis', $time, $employeeID, $date);
                                    $updateDtrStmt->execute();
                                    $updateDtrStmt->close();
                                }
                            }
                        }
                    }
/////////////
                }
                fclose($handle);
            } else {
                echo "Error reading the file.";
            }
        } else {
            echo "Uploaded file is not a CSV file.";
        }
    } else {
        echo "No file uploaded or there was an upload error.";
    }
} else {
    echo "Invalid request.";
}

////////////////////////////
if (isset($_POST['submit'])) {
    if (isset($_FILES['csvFile']) && $_FILES['csvFile']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['csvFile']['tmp_name'];
        $fileName = $_FILES['csvFile']['name'];
        $fileSize = $_FILES['csvFile']['size'];
        $fileType = $_FILES['csvFile']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        $allowedfileExtensions = array('csv');
        if (in_array($fileExtension, $allowedfileExtensions)) {
            if (($handle = fopen($fileTmpPath, 'r')) !== FALSE) {
                fgetcsv($handle);
                while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
//get, update, insert to tbl_dtr
                    $name = $data[1];
                    $employeeID = $data[2];
                    $datetime = $data[3];
                    $date = date("Y-m-d", strtotime($datetime)); 

                    $compSQL = "SELECT * FROM tbl_initialdtr WHERE employee_id = ? AND date = ?";
                    $compStmt = $conn->prepare($compSQL);
                    $compStmt->bind_param('is', $employeeID, $date);
                    $compStmt->execute();
                    $compResult = $compStmt->get_result();

                    if ($compResult->num_rows > 0) {
                        $compute = $compResult->fetch_assoc();
                    
                        if ($compute !== null) {
                            $empID = $compute['employee_id'];
                            $am_clockini = $compute['am_clockin'];
                            $am_clockouti = $compute['am_clockout'];
                            $pm_clockini = $compute['pm_clockin'];
                            $pm_clockouti = $compute['pm_clockout'];
                            $date = $compute['date'];


                            $am_clockin = new DateTime($am_clockini);
                            $am_clockout = new DateTime($am_clockouti);
                            $pm_clockin = new DateTime($pm_clockini);
                            $pm_clockout = new DateTime($pm_clockouti);

                            if($am_clockini != '00:00:00' && $am_clockouti != '00:00:00' && $pm_clockini != '00:00:00' && $pm_clockouti != '00:00:00'){
                                $am_interval = $am_clockin->diff($am_clockout);
                                $pm_interval = $pm_clockin->diff($pm_clockout);
                                $lunch_interval = $am_clockout->diff($pm_clockin);

                                $lunch_minutes = ($lunch_interval->h * 60) + $lunch_interval->i;
                                $am_minutes = ($am_interval->h * 60) + $am_interval->i;
                                $pm_minutes = ($pm_interval->h * 60) + $pm_interval->i;

                                if($lunch_minutes <= 60){
                                    $lunch = 60;
                                }else{
                                    $lunch = $lunch_minutes;
                                }

                                $total_minutes = $am_minutes + $pm_minutes - $lunch;
                                $total_hours = ($total_minutes / 60);

                                $updateDtrSql = "UPDATE tbl_initialdtr SET totalhours = ? WHERE employee_id = ? AND date = ?";
                                $updateDtrStmt = $conn->prepare($updateDtrSql);
                                $updateDtrStmt->bind_param('dis', $total_hours, $employeeID, $date);
                                $updateDtrStmt->execute();
                                $updateDtrStmt->close();
                            }else if($am_clockini != '00:00:00' && $am_clockouti == '00:00:00' && $pm_clockini == '00:00:00' && $pm_clockouti != '00:00:00'){
                                $time_interval = $am_clockin->diff($pm_clockout);
                                $time_minutes = ($time_interval->h * 60) + $time_interval->i;
                                $lunch = 60; 
                                $total_minutes = $time_minutes - $lunch;
                                $total_hours = ($total_minutes / 60);

                                $updateDtrSql = "UPDATE tbl_initialdtr SET totalhours = ? WHERE employee_id = ? AND date = ?";
                                $updateDtrStmt = $conn->prepare($updateDtrSql);
                                $updateDtrStmt->bind_param('dis', $total_hours, $employeeID, $date);
                                $updateDtrStmt->execute();
                                $updateDtrStmt->close();
                            }else if($am_clockini != '00:00:00' && $am_clockouti != '00:00:00' && $pm_clockini == '00:00:00' && $pm_clockouti == '00:00:00'){
                                $am_interval = $am_clockin->diff($am_clockout);
                                $am_minutes = ($am_interval->h * 60) + $am_interval->i;
                                $total_minutes = $am_minutes;
                                $total_hours = ($total_minutes / 60);

                                $updateDtrSql = "UPDATE tbl_initialdtr SET totalhours = ? WHERE employee_id = ? AND date = ?";
                                $updateDtrStmt = $conn->prepare($updateDtrSql);
                                $updateDtrStmt->bind_param('dis', $total_hours, $employeeID, $date);
                                $updateDtrStmt->execute();
                                $updateDtrStmt->close();
                            }else if($am_clockini == '00:00:00' && $am_clockouti == '00:00:00' && $pm_clockini != '00:00:00' && $pm_clockouti != '00:00:00'){
                                $pm_interval = $pm_clockin->diff($pm_clockout);
                                $pm_minutes = ($pm_interval->h * 60) + $pm_interval->i;
                                $total_minutes = $pm_minutes;
                                $total_hours = ($total_minutes / 60);

                                $updateDtrSql = "UPDATE tbl_initialdtr SET totalhours = ? WHERE employee_id = ? AND date = ?";
                                $updateDtrStmt = $conn->prepare($updateDtrSql);
                                $updateDtrStmt->bind_param('dis', $total_hours, $employeeID, $date);
                                $updateDtrStmt->execute();
                                $updateDtrStmt->close();
                            }
        //inserting to tbl_dtr
                            
                            $tbl_dtrSQL = "SELECT * FROM tbl_dtr WHERE employee_id = ? AND date = ?";
                            $tbl_dtrSTMT = $conn->prepare($tbl_dtrSQL);
                            $tbl_dtrSTMT->bind_param('is', $empID, $date);
                            $tbl_dtrSTMT->execute();
                            $tbl_dtrSTMT->store_result();

                            if ($tbl_dtrSTMT->num_rows == 0) {
                                $getdeptSQL = "SELECT dept_code FROM tbl_employee WHERE employee_id = ?";
                                $getdeptStmt = $conn->prepare($getdeptSQL);
                                $getdeptStmt->bind_param('i', $employeeID);
                                $getdeptStmt->execute();
                                $getdeptres = $getdeptStmt->get_result(); 
                                $getdept = $getdeptres->fetch_assoc();
                                $depcode = $getdept['dept_code'];

                                $getinitialDTRSQL = "SELECT * FROM tbl_initialdtr WHERE employee_id = ? and date = ?";
                                $getinitialDTRStmt = $conn->prepare($getinitialDTRSQL);
                                $getinitialDTRStmt->bind_param('is', $employeeID, $date);
                                $getinitialDTRStmt->execute();
                                $getinitialdtrres = $getinitialDTRStmt->get_result(); 
                                $initialDTR = $getinitialdtrres->fetch_assoc();

                                $am_clock = $initialDTR['am_clockin'];
                                $am_clockk = $initialDTR['am_clockout'];
                                $pm_clock = $initialDTR['pm_clockin'];
                                $pm_clockk = $initialDTR['pm_clockout'];
                                $total = $initialDTR['totalhours']; 

                                $insertDeptSql = "INSERT INTO tbl_dtr (employee_id, name, dept_code, am_clockin, am_clockout, pm_clockin, pm_clockout, totalhours, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                                $insertDeptStmt = $conn->prepare($insertDeptSql);
                                $insertDeptStmt->bind_param('isissssds', $empID, $name, $depcode, $am_clock, $am_clockk, $pm_clock, $pm_clockk, $total, $date);
                                $insertDeptStmt->execute();
                                $insertDeptStmt->close();
                            }
                            $tbl_dtrSTMT->close();
                        } else {

                        }
                    } else {

                    }

                    




















                }
                fclose($handle);
                echo "<script>window.alert('csv file uploaded successfully');
                    window.location.href='dtr.php';</script>";
            } else {
                echo "Error reading the file.";
            }
        } else {
            echo "Uploaded file is not a CSV file.";
        }
    } else {
        echo "No file uploaded or there was an upload error.";
    }
} else {
    echo "Invalid request.";
}

///////////////////////////////////
$conn->close();
?>
