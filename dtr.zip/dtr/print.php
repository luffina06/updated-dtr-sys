<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}
include "conn.php";

if(isset($_SESSION['selectedIDs'])){
    $empIds = $_SESSION['selectedIDs'];
    $month = $_SESSION['month'];
    $year = $_SESSION['year'];

    if($month == null){
        $month = date('n');
    }
    if($year == null){
        $year = date('Y');
    }
    $dateObj = DateTime::createFromFormat('!m', $month);
    $monthName = $dateObj->format('F');
    
    foreach($empIds as $empId){

        $getnamesql = "SELECT * FROM tbl_employee WHERE employee_id = ?";
        $getnameStmt = $conn->prepare($getnamesql);
        $getnameStmt->bind_param('i', $empId);
        $getnameStmt->execute();
        $getnameResult = $getnameStmt->get_result();
        $getname = $getnameResult->fetch_assoc();

        $name = $getname['name'];
         
////////////////////////////////////////////////////////////////////////////////////////////////
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Civil Service Form No. 48</title>
    <style>
        .container{
            margin: .3in;
            color: black;
        }
        th{
            font-family: Arial;
            font-weight: normal;
        }
        .dtr-table{
            width: 100%;
            border-collapse: collapse;
            border: 1px solid black;
        }
        .dtr-table th, .dtr-table td {
            border: 1px solid black;
            padding: 1px; 
            text-align: center; 
            font-size: 12px;
        }
        .form-footer{
            font-family: Arial;
        }

        .dtr-table td, .dtr-table th {
            border: 1px solid black;
        }

        .dtr-table .thick-border-bottom{
            border-bottom: 2px solid black;
        }

        .dtr-table .thick-right {
            border-right: 2px solid black;
        }

        .thick-border {
            border: 2px solid black;
        }

        .thick-border-bottom {
            border-bottom: 2px solid black;
        }

        .no-border {
            border: none;
        }

        .thin-border {
            border: 1px solid black;
        }
    </style>
</head>
<body>
    <div class="container">
            <p class="Formno">Civil Service Form No. 48</p>
            <center>
            <h2>DAILY TIME RECORD</h2>
            <p>-----o0o-----</p>
            <span style="text-decoration: underline;"><?php echo $name?></span> <br>
            <label>(Name)</label>
            </center>
        <div class="form-group">
            <label style = "font-weight: normal; font-family: Arial;">For the month of:<b style="font-weight: bold; text-decoration: underline;">  <?php echo $monthName?></b></label>
        </div>
        <table>
            <tr>
                <th rowspan = "2"><i>Official Hours for<br>arrival and departure</i></th>
                <th>&nbsp<i>Regular Days: ________________________________________ <br> &nbsp Saturdays: ___________________________________________</i></th>
            </tr>
        </table>

        <table class="dtr-table">
            <thead>
                <tr>
                    <th rowspan="2" class = "thick-border-bottom thick-right">Day</th>
                    <th colspan="2" class="thick-right"><b>A.M.</b></th>
                    <th colspan="2" class="thick-right"><b>P.M.</b></th>
                    <th colspan="2"><b>Undertime</b></th>
                </tr>
                <tr>
                    <th class = "thick-border-bottom"><b>Arrival</b></th>
                    <th class = "thick-border-bottom thick-right"><b>Departure</b></th>
                    <th class = "thick-border-bottom"><b>Arrival</b></th>
                    <th class = "thick-border-bottom thick-right"><b>Departure</b></th>
                    <th class = "thick-border-bottom"><b>Hours</b></th>
                    <th class = "thick-border-bottom"><b>Minutes</b></th>
                </tr>
            </thead>
            <tbody>
                <?php                 
                for($i = 1; $i <= 31; $i++){ 
                    $getdtrssql = "SELECT * FROM tbl_dtr WHERE employee_id = ? and (MONTH(date) = ? and DAY(date) = ? and YEAR(date) = ?)";
                    $getdtrsStmt = $conn->prepare($getdtrssql);
                    $getdtrsStmt->bind_param('iiii', $empId, $month, $i, $year);
                    $getdtrsStmt->execute();
                    $getdtrsResult = $getdtrsStmt->get_result();
                    // $getdtrs = $getdtrsResult->fetch_assoc();

                    $amcloockin = '';
                    $amcloockout = '';
                    $pmcloockin = '';
                    $pmcloockout = '';
                    //$totalhourss = 0;

                    if ($getdtrs = $getdtrsResult->fetch_assoc()) {
                        $amcloockin = $getdtrs['am_clockin'];
                        $amcloockout = $getdtrs['am_clockout'];
                        $pmcloockin = $getdtrs['pm_clockin'];
                        $pmcloockout = $getdtrs['pm_clockout'];
                       // $totalhourss = $getdtrs['totalhours'];
                    }
                    // $hours = floor($totalhourss);
                    // $minutes = round(($totalhourss - $hours) * 60);

                    // $hours = $hours+$hours;
                    // $minutes = $minutes+$minutes;

                    // if($minutes >= 60){
                    //     $minutes - 60;
                    //     $hours + 1;
                    // }
                    $getdtrsStmt->close();

                    // $amcloockin = $getdtrs['am_clockin'];
                    // $amcloockout = $getdtrs['am_clockout'];
                    // $pmcloockin = $getdtrs['pm_clockin'];
                    // $pmcloockout = $getdtrs['pm_clockout'];
                    
                ?>
                    <tr>
                        <td class="thick-border thick-right"><?php echo $i ?></td>
                        <td class="thin-border"><?php echo $amcloockin ?></td>
                        <td class="thin-border thick-right"><?php echo $amcloockout ?></td>
                        <td class="thin-border"><?php echo $pmcloockin ?></td>
                        <td class="thin-border thick-right"><?php echo $pmcloockout ?></td>
                        <td class="thin-border"></td>
                        <td class="thin-border"></td>
                    </tr>
                <?php 
                }
                    $getdtrssql = "SELECT * FROM tbl_dtr WHERE employee_id = ? and (MONTH(date) = ? and YEAR(date) = ?)";
                    $getdtrsStmt = $conn->prepare($getdtrssql);
                    $getdtrsStmt->bind_param('iii', $empId, $month, $year);
                    $getdtrsStmt->execute();
                    $getdtrsResult = $getdtrsStmt->get_result();


                    $total_hours = 0;
                    $total_minutes = 0;

                    while ($getdtrs = $getdtrsResult->fetch_assoc()) {
                        $ot = $getdtrs['ot'];



                        if($ot == 1){

                            $totalhours = $getdtrs['totalhours'];

                            if($totalhours <= 0){
                                $totalhours = 0;
                            }
                             
                            $hours = floor($totalhours);
                            $minutes = round(($totalhours - $hours) * 60);

                            $total_hours += $hours;
                            $total_minutes += $minutes;
                            if ($total_minutes >= 60) {
                                $total_hours += floor($total_minutes / 60);
                                $total_minutes = $total_minutes % 60;
                            }
                        }else if($ot == 0){
                            $totalhours = $getdtrs['totalhours'];

                            if($totalhours <= 0){
                                $totalhours = 0;
                            }
                            if($totalhours >= 8){
                                $totalhours = 8;
                            }
                            
                            $hours = floor($totalhours);
                            $minutes = round(($totalhours - $hours) * 60);

                            $total_hours += $hours;
                            $total_minutes += $minutes;
                            if ($total_minutes >= 60) {
                                $total_hours += floor($total_minutes / 60);
                                $total_minutes = $total_minutes % 60;
                            }
                        }
                    }
                
                ?>
                <tr class="total-row">
                    <td colspan="5" class="thick-border thick-right">Total</td>
                    <td><?php echo $total_hours; ?></td>
                    <td><?php echo $total_minutes; ?></td>
                </tr>
            </tbody>
        </table>
        <div class="form-footer">
            <p><i>I certify on my honor that the above is a true and correct report of the hours of work performed, record of which was made daily at the time of arrival and departure from office.</i></p>
            <div class="signature">
                <span style="font-weight:bold; width: 100%;">_________________________________________________________________________________</span>
            </div>
            <p><i>VERIFIED as to the prescribed office hours:</i></p>
            <div class="signature">
            <span style="font-weight:bold; width: 100%;">_________________________________________________________________________________</span>
            </div>
            <p align = "center"><i>In Charge</i></p>
        </div>
    </div>
</body>
</html>



<div style="page-break-before: always;"></div>
<?php
////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
?>
<script>
    window.onload = function() {
        window.print();
        window.onafterprint = function(event) {
            window.location.href = 'dtr.php';
        };
    };
</script>
